"""Draws the !level card: a dark blue, ethereal butterfly scene with the member's avatar, level and
XP progress. render_level() returns PNG bytes and has no Discord dependency.
"""
import math
import os
import random
from io import BytesIO

from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont, ImageOps

from quote_image import HERE, clean_name, get_font

W, H = 1000, 360  # design size; everything is drawn at K times this and scaled down for smooth edges
K = 2

BOLD_CANDIDATES = [
    os.path.join(HERE, "font-bold.ttf"),
    r"C:\Windows\Fonts\segoeuib.ttf",
    r"C:\Windows\Fonts\arialbd.ttf",
    "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
    "/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/usr/share/fonts/TTF/DejaVuSans-Bold.ttf",
]
_bold_path = None
_bold_searched = False


def bold_font(size: int):
    global _bold_path, _bold_searched
    if not _bold_searched:
        _bold_searched = True
        for p in BOLD_CANDIDATES:
            if os.path.isfile(p):
                try:
                    ImageFont.truetype(p, 20)
                    _bold_path = p
                    break
                except OSError:
                    continue
    if _bold_path:
        try:
            return ImageFont.truetype(_bold_path, size)
        except OSError:
            pass
    return get_font(size)


def k(v):
    return int(round(v * K))


# --------------------------------------------------------------------------- #
# Colours
# --------------------------------------------------------------------------- #
NAVY_TOP = (4, 8, 24)
NAVY_BOTTOM = (8, 22, 58)
GLOW_BLUE = (40, 100, 230)
ICE = (150, 215, 255)
CYAN = (90, 200, 255)
BLUE = (60, 120, 255)
VIOLET = (140, 110, 255)
TEXT = (235, 244, 255)
MUTED = (140, 165, 205)


def _bezier(p0, p1, p2, p3, n=24):
    pts = []
    for i in range(n + 1):
        t = i / n
        a, b, c, d = (1 - t) ** 3, 3 * (1 - t) ** 2 * t, 3 * (1 - t) * t ** 2, t ** 3
        pts.append((a * p0[0] + b * p1[0] + c * p2[0] + d * p3[0], a * p0[1] + b * p1[1] + c * p2[1] + d * p3[1]))
    return pts


def _wing_polys():
    """Right-hand upper and lower wing outlines in unit coordinates (body at the origin, up is -y)."""
    upper = (
        _bezier((0.0, -0.04), (0.18, -0.95), (0.95, -1.2), (1.02, -0.55))
        + _bezier((1.02, -0.55), (1.08, -0.12), (0.62, 0.12), (0.04, 0.06))[1:]
    )
    lower = (
        _bezier((0.02, 0.05), (0.75, 0.12), (1.0, 0.6), (0.66, 0.98))
        + _bezier((0.66, 0.98), (0.42, 1.14), (0.08, 0.74), (0.0, 0.2))[1:]
    )
    return upper, lower


UPPER, LOWER = _wing_polys()


def butterfly_layer(size: int, color, accent, open_ratio=1.0, alpha=170):
    """One glowing butterfly on a transparent square canvas of `size` pixels, wings spread."""
    canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(canvas)
    cx, cy = size / 2, size / 2
    scale = size * 0.42

    def place(poly, mirror, shrink=1.0):
        return [
            (cx + (-x if mirror else x) * scale * open_ratio * shrink, cy + y * scale * shrink - scale * 0.1)
            for x, y in poly
        ]

    for mirror in (False, True):
        for poly, tint in ((LOWER, accent), (UPPER, color)):
            outer = place(poly, mirror)
            d.polygon(outer, fill=tint + (int(alpha * 0.55),))
            inner = place(poly, mirror, 0.72)
            d.polygon(inner, fill=tint + (int(alpha * 0.55),))
            core = place(poly, mirror, 0.4)
            d.polygon(core, fill=ICE + (int(alpha * 0.5),))
            d.line(outer + [outer[0]], fill=ICE + (min(255, alpha + 60),), width=max(1, size // 120))
            # veins from the body to the wing edge
            for frac in (0.22, 0.45, 0.68, 0.9):
                tip = outer[int(frac * (len(outer) - 1))]
                d.line([(cx, cy - scale * 0.05), tip], fill=ICE + (int(alpha * 0.45),), width=max(1, size // 220))
            # glowing spots along the edge
            for frac in (0.3, 0.5, 0.7):
                x, y = outer[int(frac * (len(outer) - 1))]
                r = max(2, size // 70)
                d.ellipse((x - r, y - r, x + r, y + r), fill=(235, 250, 255, min(255, alpha + 70)))
    body = [cx - size * 0.012, cy - scale * 0.45, cx + size * 0.012, cy + scale * 0.55]
    d.ellipse(body, fill=(210, 235, 255, 230))
    # antennae
    d.line([(cx, cy - scale * 0.42), (cx - scale * 0.16, cy - scale * 0.72)], fill=ICE + (200,), width=max(1, size // 160))
    d.line([(cx, cy - scale * 0.42), (cx + scale * 0.16, cy - scale * 0.72)], fill=ICE + (200,), width=max(1, size // 160))
    return canvas


def glow_composite(base: Image.Image, layer: Image.Image, radius: float, passes: int = 2) -> Image.Image:
    """Lays `layer` on `base` with a soft bloom around it."""
    halo = layer.filter(ImageFilter.GaussianBlur(radius))
    for _ in range(passes):
        base = Image.alpha_composite(base, halo)
    return Image.alpha_composite(base, layer)


# --------------------------------------------------------------------------- #
# Scene
# --------------------------------------------------------------------------- #
def _background(rng: random.Random) -> Image.Image:
    w, h = k(W), k(H)
    col = Image.new("RGB", (1, h))
    for y in range(h):
        t = y / (h - 1)
        col.putpixel((0, y), tuple(int(NAVY_TOP[i] + (NAVY_BOTTOM[i] - NAVY_TOP[i]) * t) for i in range(3)))
    img = col.resize((w, h)).convert("RGBA")

    glow = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse((k(520), k(-120), k(1120), k(330)), fill=GLOW_BLUE + (110,))
    gd.ellipse((k(-160), k(160), k(380), k(520)), fill=(30, 70, 190, 90))
    gd.ellipse((k(380), k(200), k(760), k(470)), fill=(70, 50, 180, 50))
    img = Image.alpha_composite(img, glow.filter(ImageFilter.GaussianBlur(k(70))))

    bokeh = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    bd = ImageDraw.Draw(bokeh)
    for _ in range(26):
        r = rng.randint(k(6), k(26))
        x, y = rng.randint(0, w), rng.randint(0, h)
        c = rng.choice([CYAN, BLUE, VIOLET, ICE])
        bd.ellipse((x - r, y - r, x + r, y + r), fill=c + (rng.randint(14, 40),))
    return Image.alpha_composite(img, bokeh.filter(ImageFilter.GaussianBlur(k(3))))


def _sparkles(img: Image.Image, rng: random.Random, count: int) -> Image.Image:
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    for _ in range(count):
        x, y = rng.randint(0, img.width), rng.randint(0, img.height)
        r = rng.choice([k(1), k(1), k(2), k(2), k(3)])
        a = rng.randint(120, 255)
        d.ellipse((x - r, y - r, x + r, y + r), fill=(220, 240, 255, a))
        if r >= k(3) or rng.random() < 0.08:  # a few four-point stars
            L = r * 4
            d.line([(x - L, y), (x + L, y)], fill=(200, 230, 255, a // 2), width=max(1, k(1) // 2))
            d.line([(x, y - L), (x, y + L)], fill=(200, 230, 255, a // 2), width=max(1, k(1) // 2))
    return glow_composite(img, layer, k(3), passes=1)


PALETTES = [(CYAN, BLUE), (BLUE, VIOLET), (ICE, CYAN)]
BACK_SPOTS = [  # (centre x, centre y, size, rotation degrees, opacity, palette index): behind the panel
    (905, 22, 270, -16, 165, 0),
    (62, 318, 270, 24, 160, 1),
    (575, 342, 110, 12, 110, 2),
    (392, 14, 80, -25, 100, 0),
]
FRONT_SPOTS = [  # drawn over the panel's edge for depth
    (968, 314, 120, 30, 175, 1),
    (258, 36, 76, -22, 175, 0),
    (979, 196, 44, 18, 150, 2),
]


def _butterflies(img: Image.Image, rng: random.Random, spots: list) -> Image.Image:
    for cx, cy, size, rot, alpha, pal in spots:
        color, accent = PALETTES[pal]
        fly = butterfly_layer(k(size), color, accent, open_ratio=rng.uniform(0.84, 1.0), alpha=alpha)
        fly = fly.rotate(rot, resample=Image.BICUBIC, expand=True)
        layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
        layer.paste(fly, (k(cx) - fly.width // 2, k(cy) - fly.height // 2))  # no mask: it would square the alpha
        img = glow_composite(img, layer, k(size) / 22, passes=2)
    return img


def _avatar(avatar_bytes, initial: str, diameter: int) -> Image.Image:
    img = None
    if avatar_bytes:
        try:
            img = Image.open(BytesIO(avatar_bytes))
            img.load()
            img = img.convert("RGBA")
            flat = Image.new("RGBA", img.size, (10, 20, 50, 255))
            flat.alpha_composite(img)
            img = ImageOps.fit(flat.convert("RGB"), (diameter, diameter), method=Image.LANCZOS)
        except Exception:
            img = None
    if img is None:
        img = Image.new("RGB", (diameter, diameter), (18, 36, 84))
        f = bold_font(int(diameter * 0.55))
        letter = (initial or "?")[:1].upper()
        ImageDraw.Draw(img).text(((diameter - f.getlength(letter)) / 2, diameter * 0.16), letter, font=f, fill=(120, 170, 255))
    mask = Image.new("L", (diameter * 4, diameter * 4), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, diameter * 4 - 1, diameter * 4 - 1), fill=255)
    mask = mask.resize((diameter, diameter), Image.LANCZOS)
    out = Image.new("RGBA", (diameter, diameter), (0, 0, 0, 0))
    out.paste(img, (0, 0), mask)
    return out


def _spaced(draw, xy, text, font, fill, spacing):
    x, y = xy
    for ch in text:
        draw.text((x, y), ch, font=font, fill=fill)
        x += font.getlength(ch) + spacing
    return x


def _spaced_width(text, font, spacing):
    return sum(font.getlength(c) + spacing for c in text) - spacing


def _fit(text, font_fn, size, max_w, min_size=None):
    min_size = min_size or int(size * 0.62)  # shrink a bit, then cut with an ellipsis
    while size > min_size and font_fn(size).getlength(text) > max_w:
        size -= 2
    font = font_fn(size)
    if font.getlength(text) > max_w:
        while text and font.getlength(text + "\u2026") > max_w:
            text = text[:-1]
        text = text.rstrip() + "\u2026"
    return text, font


def _gradient_bar(width: int, height: int) -> Image.Image:
    bar = Image.new("RGBA", (width, height))
    px = bar.load()
    stops = [(0.0, (60, 200, 255)), (0.55, (70, 130, 255)), (1.0, (150, 110, 255))]
    for x in range(width):
        t = x / max(1, width - 1)
        for (t0, c0), (t1, c1) in zip(stops, stops[1:]):
            if t0 <= t <= t1:
                f = (t - t0) / (t1 - t0)
                c = tuple(int(c0[i] + (c1[i] - c0[i]) * f) for i in range(3))
                break
        for y in range(height):
            shine = 1.0 + 0.25 * (1 - abs(y - height * 0.3) / height)  # light along the top edge
            px[x, y] = tuple(min(255, int(v * shine)) for v in c) + (255,)
    return bar


def render_level_butterflies(
    name: str,
    handle: str,
    avatar_bytes,
    level: int,
    title: str,
    into: int,
    needed: int,
    total_xp: int,
    rank: str,
    messages: int,
    seed: int = 0,
) -> bytes:
    rng = random.Random(seed or 1)
    name = clean_name(name, fallback="Unknown")
    handle = clean_name(handle, fallback="")
    fraction = max(0.0, min(1.0, into / needed if needed else 0))

    img = _background(rng)
    extra = [
        (rng.randint(470, 640), rng.randint(300, 345), rng.randint(40, 70), rng.randint(-40, 40), rng.randint(90, 130), rng.randint(0, 2))
        for _ in range(min(3, level // 8))  # a few more butterflies as you level up
    ]
    img = _butterflies(img, rng, BACK_SPOTS + extra)
    img = _sparkles(img, rng, 70)

    # frosted panel behind the text
    panel = Image.new("RGBA", img.size, (0, 0, 0, 0))
    pd = ImageDraw.Draw(panel)
    box = (k(268), k(28), k(970), k(332))
    pd.rounded_rectangle(box, radius=k(30), fill=(6, 14, 38, 185))
    img = Image.alpha_composite(img, panel)
    edge = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(edge).rounded_rectangle(box, radius=k(30), outline=(110, 170, 255, 120), width=k(2))
    img = glow_composite(img, edge, k(5), passes=1)
    img = _butterflies(img, rng, FRONT_SPOTS)

    # avatar with a glowing ring
    av_d, cx, cy = k(196), k(138), k(H / 2)
    ring = Image.new("RGBA", img.size, (0, 0, 0, 0))
    rd = ImageDraw.Draw(ring)
    r_out = av_d // 2 + k(12)
    rd.ellipse((cx - r_out, cy - r_out, cx + r_out, cy + r_out), outline=CYAN + (255,), width=k(4))
    r_in = r_out + k(12)
    rd.ellipse((cx - r_in, cy - r_in, cx + r_in, cy + r_in), outline=BLUE + (150,), width=k(2))
    img = glow_composite(img, ring, k(9), passes=3)
    avatar = _avatar(avatar_bytes, name, av_d)
    img.alpha_composite(avatar, (cx - av_d // 2, cy - av_d // 2))

    draw = ImageDraw.Draw(img)
    left, right = k(300), k(938)

    # name and handle
    shown_name, name_font = _fit(name, bold_font, k(42), k(430))
    draw.text((left, k(46)), shown_name, font=name_font, fill=TEXT)
    if handle:
        draw.text((left, k(46) + int(name_font.size * 1.25)), "@" + handle[:32], font=get_font(k(21)), fill=MUTED)

    # level, top right
    lvl_font, lbl_font = bold_font(k(86)), get_font(k(20))
    num = str(level)
    num_w = lvl_font.getlength(num)
    lx = right - num_w
    glow_txt = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(glow_txt).text((lx, k(34)), num, font=lvl_font, fill=CYAN + (255,))
    img = glow_composite(img, glow_txt, k(7), passes=2)
    draw = ImageDraw.Draw(img)
    label = "LEVEL"
    _spaced(draw, (lx - _spaced_width(label, lbl_font, k(4)) - k(14), k(62)), label, lbl_font, MUTED, k(4))
    title_font = bold_font(k(21))
    t_text = f"\u2726 {title}"
    draw.text((right - title_font.getlength(t_text), k(34) + int(lvl_font.size * 1.05)), t_text, font=title_font, fill=ICE)

    # stat chips
    chip_font, chip_label = bold_font(k(26)), get_font(k(15))
    stats = [("RANK", rank), ("TOTAL XP", f"{total_xp:,}"), ("MESSAGES", f"{messages:,}")]
    x = left
    for label, value in stats:
        _spaced(draw, (x, k(150)), label, chip_label, MUTED, k(2))
        draw.text((x, k(150) + int(chip_label.size * 1.35)), value, font=chip_font, fill=TEXT)
        x += max(chip_font.getlength(value), _spaced_width(label, chip_label, k(2))) + k(44)

    # xp text and bar
    xp_font, small = bold_font(k(24)), get_font(k(20))
    draw.text((left, k(212)), f"{into:,} / {needed:,} XP", font=xp_font, fill=TEXT)
    pct = f"{int(fraction * 100)}%"
    draw.text((right - small.getlength(pct), k(215)), pct, font=small, fill=ICE)

    bar_x0, bar_y0, bar_x1, bar_y1 = left, k(248), right, k(278)
    track = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(track).rounded_rectangle((bar_x0, bar_y0, bar_x1, bar_y1), radius=k(15), fill=(14, 28, 68, 230), outline=(70, 110, 190, 160), width=k(1))
    img = Image.alpha_composite(img, track)
    fill_w = int((bar_x1 - bar_x0) * fraction)
    if fill_w > k(10):
        bar = _gradient_bar(fill_w, bar_y1 - bar_y0)
        mask = Image.new("L", bar.size, 0)
        ImageDraw.Draw(mask).rounded_rectangle((0, 0, bar.width - 1, bar.height - 1), radius=k(15), fill=255)
        glow_layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
        glow_layer.paste(bar, (bar_x0, bar_y0), mask)
        img = glow_composite(img, glow_layer, k(8), passes=2)
        # a bright dot on the leading edge
        tip = Image.new("RGBA", img.size, (0, 0, 0, 0))
        ex, ey, er = bar_x0 + fill_w - k(8), (bar_y0 + bar_y1) // 2, k(5)
        ImageDraw.Draw(tip).ellipse((ex - er, ey - er, ex + er, ey + er), fill=(240, 252, 255, 255))
        img = glow_composite(img, tip, k(5), passes=2)

    draw = ImageDraw.Draw(img)
    remaining = max(0, needed - into)
    draw.text((left, k(288)), f"{remaining:,} XP until level {level + 1}", font=small, fill=MUTED)

    out = img.convert("RGB").resize((W, H), Image.LANCZOS)
    buf = BytesIO()
    out.save(buf, "PNG", optimize=True)
    return buf.getvalue()


# --------------------------------------------------------------------------- #
# Gothic template card: uses the artwork in level_bg.png (a 1024x1024 scene with an arched frame on
# the left for the avatar and two dark bars for text). If the file is missing the butterfly card
# above is used instead.
# --------------------------------------------------------------------------- #
BG_PATH = os.environ.get("LEVEL_BG") or os.path.join(HERE, "level_bg.png")
_bg_cache = None

# Layout in the 1024x1024 artwork (change these if you swap in different artwork)
FRAME = (64, 240, 236, 458)  # the avatar goes in this arch: x0, y0, x1, y1
TEXT_L, TEXT_R = 240, 792  # left and right edges of the dark bars
BAR1_Y = 482  # top of the first bar's contents
BAR2_Y = 686


def _find_background():
    """level_bg.png next to the code (also accepts browser-renamed copies like 'level_bg (1).png')."""
    if os.path.isfile(BG_PATH):
        return BG_PATH
    for folder in (HERE, os.getcwd()):
        try:
            for f in sorted(os.listdir(folder)):
                if f.lower().startswith("level_bg") and f.lower().endswith((".png", ".jpg", ".jpeg", ".webp")):
                    return os.path.join(folder, f)
        except OSError:
            pass
    return None


def load_background():
    global _bg_cache
    if _bg_cache is None:
        path = _find_background()
        try:
            if not path:
                raise FileNotFoundError(f"level_bg.png not found (looked in {HERE})")
            img = Image.open(path).convert("RGB")
            _bg_cache = img.resize((1024, 1024), Image.LANCZOS) if img.size != (1024, 1024) else img
            print(f"Level card: using background {path}")
        except Exception as e:
            print(f"Level card: NOT using the gothic card, falling back to the butterfly one: {e!r}")
            _bg_cache = False
    return _bg_cache or None


def _arch_avatar(avatar_bytes, initial: str, w: int, h: int) -> Image.Image:
    """The avatar cut into an arch (round top, straight sides) and tinted to sit in the dark blue scene."""
    base = _avatar(avatar_bytes, initial, max(w, h))  # square, circular; we want the full square
    sq = Image.new("RGBA", (max(w, h), max(w, h)))
    # re-decode without the circle: rebuild from bytes for the full image
    img = None
    if avatar_bytes:
        try:
            raw = Image.open(BytesIO(avatar_bytes))
            raw.load()
            raw = raw.convert("RGBA")
            flat = Image.new("RGBA", raw.size, (10, 20, 50, 255))
            flat.alpha_composite(raw)
            img = ImageOps.fit(flat.convert("RGB"), (w, h), method=Image.LANCZOS, centering=(0.5, 0.35))
        except Exception:
            img = None
    if img is None:
        img = Image.new("RGB", (w, h), (18, 36, 84))
        f = bold_font(int(w * 0.6))
        letter = (initial or "?")[:1].upper()
        ImageDraw.Draw(img).text(((w - f.getlength(letter)) / 2, h * 0.18), letter, font=f, fill=(120, 170, 255))
    # cool blue grade so any photo matches the scene
    grey = ImageOps.grayscale(img).convert("RGB")
    graded = Image.blend(img, ImageChops.multiply(grey, Image.new("RGB", (w, h), (120, 170, 255))), 0.55)
    graded = ImageEnhance_brightness(graded, 0.92)
    # arch mask, drawn big and shrunk for smooth edges
    S = 4
    mask = Image.new("L", (w * S, h * S), 0)
    md = ImageDraw.Draw(mask)
    r = w * S // 2
    md.pieslice((0, 0, w * S - 1, 2 * r), 180, 360, fill=255)
    md.rectangle((0, r, w * S - 1, h * S - 1), fill=255)
    mask = mask.resize((w, h), Image.LANCZOS).filter(ImageFilter.GaussianBlur(1.2))
    out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    out.paste(graded, (0, 0), mask)
    # darken toward the edges so it melts into the frame
    vignette = Image.new("L", (w, h), 0)
    ImageDraw.Draw(vignette).ellipse((-w * 0.15, -h * 0.1, w * 1.15, h * 1.1), fill=255)
    vignette = vignette.filter(ImageFilter.GaussianBlur(w * 0.18))
    dark = Image.new("RGBA", (w, h), (4, 8, 24, 255))
    inv = ImageChops.invert(vignette)
    out.alpha_composite(Image.composite(dark, Image.new("RGBA", (w, h), (0, 0, 0, 0)), inv))
    out.putalpha(ImageChops.multiply(out.getchannel("A"), mask))
    return out


def ImageEnhance_brightness(img, factor):
    from PIL import ImageEnhance

    return ImageEnhance.Brightness(img).enhance(factor)


def _glow_text(img, xy, text, font, color, radius, passes=2):
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(layer).text(xy, text, font=font, fill=color + (255,))
    return glow_composite(img, layer, radius, passes)


FONT_DIR = os.path.join(HERE, "fonts")
_FONT_FILES = {
    "demi": ["medieval-demi.otf"],
    "caps": ["medieval-caps.otf"],
    "ital": ["medieval-italic.otf"],
    "orn": ["ornaments.ttf"],
}
_SYSTEM_FALLBACK = {
    "demi": ["/usr/share/fonts/truetype/freefont/FreeSerifBold.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf"],
    "caps": ["/usr/share/fonts/truetype/freefont/FreeSerif.ttf"],
    "ital": ["/usr/share/fonts/truetype/freefont/FreeSerifItalic.ttf"],
    "orn": ["/usr/share/fonts/truetype/freefont/FreeSerif.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", r"C:\Windows\Fonts\seguisym.ttf"],
}


def med_font(kind: str, size: int):
    """Medieval-style fonts from the fonts/ folder; falls back to other serifs, then the default font."""
    paths = [os.path.join(FONT_DIR, f) for f in _FONT_FILES[kind]] + _SYSTEM_FALLBACK[kind]
    for p in paths:
        if os.path.isfile(p):
            try:
                return ImageFont.truetype(p, size)
            except OSError:
                continue
    return bold_font(size) if kind == "demi" else get_font(size)


# wide card (same shape as before so it doesn't take over the channel)
GW, GH = 1000, 360
CROP_Y = 214  # which slice of level_bg.png is used (the arched frame ends up on the left)
G_FRAME = (62, 26, 231, 244)  # avatar arch in card coordinates
SILVER = (214, 226, 248)
GOLD = (196, 214, 255)  # a pale, cold "gilt" that stays in the blue palette
INK = (6, 12, 34)


def _wide_background(bg: Image.Image) -> Image.Image:
    scale = GW / bg.width
    h = int(round(bg.height * scale))
    scaled = bg.resize((GW, h), Image.LANCZOS)
    y0 = int(CROP_Y * scale)
    img = scaled.crop((0, y0, GW, y0 + GH)).convert("RGBA")
    # a dark, softly blurred panel behind the text so it reads clearly
    panel = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(panel).rounded_rectangle((262, 22, 968, 338), radius=18, fill=(3, 7, 22, 190))
    panel = panel.filter(ImageFilter.GaussianBlur(10))
    img.alpha_composite(panel)
    # gentle vignette
    vig = Image.new("L", img.size, 0)
    ImageDraw.Draw(vig).ellipse((-180, -120, GW + 180, GH + 120), fill=255)
    vig = vig.filter(ImageFilter.GaussianBlur(70))
    img = Image.composite(img, Image.new("RGBA", img.size, (2, 4, 14, 255)), vig)
    return img


def _ornate_border(img: Image.Image) -> Image.Image:
    """Double-line frame with little corner crosses, like an illuminated page."""
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    col = ICE + (230,)
    d.rounded_rectangle((7, 7, GW - 8, GH - 8), radius=10, outline=col, width=2)
    d.rounded_rectangle((13, 13, GW - 14, GH - 14), radius=6, outline=ICE + (110,), width=1)
    orn = med_font("orn", 26)
    for (x, y) in ((10, 10), (GW - 10, 10), (10, GH - 10), (GW - 10, GH - 10)):
        d.ellipse((x - 11, y - 11, x + 11, y + 11), fill=INK + (255,), outline=col, width=2)
        g = "\u2720"
        d.text((x, y), g, font=orn, fill=(235, 246, 255, 255), anchor="mm")
    return glow_composite(img, layer, 5, passes=1)


def _divider(img: Image.Image, x0: int, x1: int, y: int, glyph="\u2766") -> Image.Image:
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    mid = (x0 + x1) // 2
    orn = med_font("orn", 26)
    gap = 20
    for sx, ex in ((x0, mid - gap), (mid + gap, x1)):
        d.line((sx, y, ex, y), fill=ICE + (190,), width=1)
        d.line((sx, y + 3, ex, y + 3), fill=ICE + (70,), width=1)
    for dx, s in ((-10, 3), (0, 6), (10, 3)):
        d.polygon([(mid + dx, y + 1 - s), (mid + dx + s, y + 1), (mid + dx, y + 1 + s), (mid + dx - s, y + 1)], fill=(225, 240, 255, 255))
    for x in (x0, x1):
        d.polygon([(x, y - 4), (x + 4, y + 1), (x, y + 6), (x - 4, y + 1)], fill=CYAN + (255,))
    return glow_composite(img, layer, 4, passes=1)


def render_level_gothic(
    bg, name, handle, avatar_bytes, level, title, into, needed, total_xp, rank, messages, seed=0
) -> bytes:
    rng = random.Random(seed or 1)
    name = clean_name(name, fallback="Unknown")
    handle = clean_name(handle, fallback="")
    fraction = max(0.0, min(1.0, into / needed if needed else 0))
    img = _wide_background(bg)

    # avatar in the arched mirror frame
    fx0, fy0, fx1, fy1 = G_FRAME
    aw, ah = fx1 - fx0, fy1 - fy0
    halo = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(halo).rounded_rectangle((fx0 - 3, fy0 - 3, fx1 + 3, fy1 + 3), radius=aw // 2, outline=CYAN + (210,), width=3)
    img = glow_composite(img, halo, 9, passes=2)
    img.alpha_composite(_arch_avatar(avatar_bytes, name, aw, ah), (fx0, fy0))
    img = _sparkles(img, rng, 20)

    L, R = 282, 944  # text column
    lvl_font = med_font("demi", 104)
    num = str(level)
    num_w = lvl_font.getlength(num)

    # name (big, fancy) + handle
    shown, name_font = _fit(name, lambda s: med_font("demi", s), 56, R - L - num_w - 40, min_size=34)
    img = _glow_text(img, (L, 30), shown, name_font, TEXT, 5, 1)
    draw = ImageDraw.Draw(img)
    if handle:
        draw.text((L + 2, 30 + int(name_font.size * 1.18)), "@" + handle[:32], font=med_font("ital", 26), fill=MUTED)

    # level, top right
    lbl = med_font("caps", 22)
    label = "LEVEL"
    _spaced(draw, (R - _spaced_width(label, lbl, 7) - num_w / 2 + _spaced_width(label, lbl, 7) / 2 - 0, 22), label, lbl, GOLD, 7)
    img = _glow_text(img, (R - num_w, 30), num, lvl_font, CYAN, 10, 2)

    # title with ornaments, under the level
    draw = ImageDraw.Draw(img)
    orn22, title_font = med_font("orn", 22), med_font("caps", 26)
    tw = _spaced_width(title, title_font, 3)
    tx = R - tw
    _spaced(draw, (tx, 148), title, title_font, ICE, 3)
    draw.text((tx - 8, 160), "\u2720", font=orn22, fill=GOLD, anchor="rm")
    img = _divider(img, L, R, 192)

    # XP line
    draw = ImageDraw.Draw(img)
    xp_font = med_font("demi", 30)
    draw.text((L, 206), f"{into:,} / {needed:,}", font=xp_font, fill=TEXT)
    xw = xp_font.getlength(f"{into:,} / {needed:,}")
    draw.text((L + xw + 8, 216), "XP", font=med_font("caps", 24), fill=GOLD)
    pct = f"{int(fraction * 100)}%"
    pf = med_font("ital", 26)
    draw.text((R - pf.getlength(pct), 212), pct, font=pf, fill=ICE)

    # bar with diamond end-caps
    bx0, by0, bx1, by1 = L, 248, R, 274
    track = Image.new("RGBA", img.size, (0, 0, 0, 0))
    td = ImageDraw.Draw(track)
    td.rounded_rectangle((bx0, by0, bx1, by1), radius=13, fill=(8, 16, 46, 240), outline=ICE + (200,), width=2)
    td.rounded_rectangle((bx0 + 4, by0 + 4, bx1 - 4, by1 - 4), radius=9, outline=ICE + (60,), width=1)
    img = Image.alpha_composite(img, track)
    fill_w = int((bx1 - bx0 - 8) * fraction)
    if fill_w > 10:
        bar = _gradient_bar(fill_w, by1 - by0 - 8)
        m = Image.new("L", bar.size, 0)
        ImageDraw.Draw(m).rounded_rectangle((0, 0, bar.width - 1, bar.height - 1), radius=9, fill=255)
        layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
        layer.paste(bar, (bx0 + 4, by0 + 4), m)
        img = glow_composite(img, layer, 8, passes=2)
        tip = Image.new("RGBA", img.size, (0, 0, 0, 0))
        ex, ey = bx0 + 4 + fill_w - 7, (by0 + by1) // 2
        ImageDraw.Draw(tip).ellipse((ex - 4, ey - 4, ex + 4, ey + 4), fill=(240, 252, 255, 255))
        img = glow_composite(img, tip, 5, passes=2)
    caps = Image.new("RGBA", img.size, (0, 0, 0, 0))
    cd = ImageDraw.Draw(caps)
    for x in (bx0 - 8, bx1 + 8):
        cy = (by0 + by1) // 2
        cd.polygon([(x, cy - 9), (x + 7, cy), (x, cy + 9), (x - 7, cy)], fill=INK + (255,), outline=CYAN + (255,))
    img = glow_composite(img, caps, 4, passes=1)

    draw = ImageDraw.Draw(img)
    draw.text((L, 280), f"{max(0, needed - into):,} XP until level {level + 1}", font=med_font("ital", 21), fill=MUTED)

    # stats on one line, separated by fleurons
    lab_font, val_font, orn = med_font("caps", 19), med_font("demi", 26), med_font("orn", 20)
    stats = (("RANK", str(rank)), ("TOTAL XP", f"{total_xp:,}"), ("MESSAGES", f"{messages:,}"))
    sep = 34
    parts = []
    for lab, value in stats:
        parts.append((lab, value, _spaced_width(lab, lab_font, 3) + 10 + val_font.getlength(value)))
    x = L
    for i, (lab, value, w) in enumerate(parts):
        _spaced(draw, (x, 309), lab, lab_font, GOLD, 3)
        lx = x + _spaced_width(lab, lab_font, 3) + 10
        draw.text((lx, 302), value, font=val_font, fill=TEXT)
        x += w
        if i < len(parts) - 1:
            cx, cy = x + sep / 2, 320
            draw.polygon([(cx, cy - 5), (cx + 5, cy), (cx, cy + 5), (cx - 5, cy)], fill=ICE)
            x += sep

    img = _ornate_border(img)
    buf = BytesIO()
    img.convert("RGB").save(buf, "PNG", compress_level=4)
    return buf.getvalue()


def render_level(*args, **kwargs) -> bytes:
    """The gothic card when level_bg.png is present, otherwise the butterfly card."""
    bg = load_background()
    if bg is not None:
        return render_level_gothic(bg, *args, **kwargs)
    return render_level_butterflies(*args, **kwargs)
