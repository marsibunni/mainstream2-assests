"""Draws the quote card: the author's avatar (black and white, fading into black)
on the left, the quote and the author's name on the right.

render_quote() returns PNG bytes and has no Discord dependency, so it can be
tested on its own.
"""
import glob
import os
import re
from io import BytesIO

from PIL import Image, ImageDraw, ImageFont, ImageOps

W, H = 1200, 630
AVATAR_W = 630  # width of the avatar panel on the left
TEXT_CX = 885  # horizontal centre of the text column
TEXT_W = 540  # width of the text column
MAX_QUOTE_H = 390  # tallest the quote itself may get
MAX_CHARS = 700

WHITE = (255, 255, 255)
NAME_COLOR = (232, 232, 232)
HANDLE_COLOR = (150, 150, 150)
FOOTER_COLOR = (105, 105, 105)

HERE = os.path.dirname(os.path.abspath(__file__))

# Looked at in order. Put a font file named font.ttf (or .otf) next to bot.py, or
# set QUOTE_FONT to a font path, to use your own.
FONT_CANDIDATES = [
    os.environ.get("QUOTE_FONT", ""),
    os.path.join(HERE, "font.ttf"),
    os.path.join(HERE, "font.otf"),
    # Windows
    r"C:\Windows\Fonts\segoeui.ttf",
    r"C:\Windows\Fonts\arial.ttf",
    # macOS
    "/System/Library/Fonts/Supplemental/Arial.ttf",
    "/Library/Fonts/Arial.ttf",
    "/System/Library/Fonts/Helvetica.ttc",
    # Linux
    "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    "/usr/share/fonts/TTF/DejaVuSans.ttf",
]

_font_path = None
_font_searched = False


def _find_font_path():
    global _font_path, _font_searched
    if not _font_searched:
        _font_searched = True
        for path in FONT_CANDIDATES:
            if path and os.path.isfile(path):
                try:
                    ImageFont.truetype(path, 20)
                except OSError:
                    continue
                _font_path = path
                break
    return _font_path


def get_font(size: int):
    path = _find_font_path()
    if path:
        try:
            return ImageFont.truetype(path, size)
        except OSError:
            pass
    try:
        return ImageFont.load_default(size)  # Pillow 10.1+ ships a scalable font
    except TypeError:
        return ImageFont.load_default()


# --------------------------------------------------------------------------- #
# Text
# --------------------------------------------------------------------------- #
CUSTOM_EMOJI_RE = re.compile(r"<a?:(\w+):\d+>")
SPOILER_RE = re.compile(r"\|\|.+?\|\|", re.S)
# Colour emoji can't be drawn with a normal font (they'd show as empty boxes), so drop them
EMOJI_RE = re.compile(
    "[\U0001F000-\U0001FAFF\U0001F1E6-\U0001F1FF\u2600-\u27BF\u2B00-\u2BFF\u2190-\u21FF"
    "\u2300-\u23FF\uFE0F\uFE0E\u200D\u20E3]"
)
MARKDOWN_RE = re.compile(r"(\*\*|__|~~|```|`)")
ZERO_WIDTH_RE = re.compile("[​‌⁠﻿]")  # Discord adds these when it defuses @everyone


def clean_name(name: str, fallback: str = "Unknown") -> str:
    name = ZERO_WIDTH_RE.sub("", EMOJI_RE.sub("", name or ""))
    return " ".join(name.split()) or fallback


def clean_text(text: str) -> str:
    text = ZERO_WIDTH_RE.sub("", text)
    text = CUSTOM_EMOJI_RE.sub(lambda m: f":{m.group(1)}:", text)
    text = SPOILER_RE.sub("[spoiler]", text)
    text = EMOJI_RE.sub("", text)
    text = MARKDOWN_RE.sub("", text)
    text = re.sub(r"^\s*>+\s?", "", text, flags=re.M)  # block quote markers
    lines = [re.sub(r"[ \t]+", " ", line).strip() for line in text.splitlines()]
    text = "\n".join(line for line in lines if line)
    if len(text) > MAX_CHARS:
        text = text[: MAX_CHARS - 1].rstrip() + "\u2026"
    return text


def wrap(text: str, font, max_width: int):
    lines = []
    for paragraph in text.split("\n"):
        current = ""
        for word in paragraph.split(" "):
            trial = f"{current} {word}" if current else word
            if font.getlength(trial) <= max_width:
                current = trial
                continue
            if current:
                lines.append(current)
                current = ""
            while font.getlength(word) > max_width:  # a single word wider than the column
                cut = len(word)
                while cut > 1 and font.getlength(word[:cut]) > max_width:
                    cut -= 1
                lines.append(word[:cut])
                word = word[cut:]
            current = word
        if current:
            lines.append(current)
    return lines


def fit_quote(text: str):
    """Largest font size at which the whole quote fits. Returns (font, size, lines, line_height)."""
    for size in range(66, 21, -2):
        font = get_font(size)
        lines = wrap(text, font, TEXT_W)
        line_h = int(size * 1.22)
        if len(lines) * line_h <= MAX_QUOTE_H:
            return font, size, lines, line_h
    font = get_font(22)
    line_h = int(22 * 1.22)
    lines = wrap(text, font, TEXT_W)
    keep = max(1, MAX_QUOTE_H // line_h)
    lines = lines[:keep]
    last = lines[-1].rstrip()
    while last and font.getlength(last + "\u2026") > TEXT_W:
        last = last[:-1].rstrip()
    lines[-1] = last + "\u2026"
    return font, 22, lines, line_h


def _truncate(text: str, font, max_width: int) -> str:
    if font.getlength(text) <= max_width:
        return text
    while text and font.getlength(text + "\u2026") > max_width:
        text = text[:-1]
    return text.rstrip() + "\u2026"


def _slanted_text(canvas: Image.Image, center_x: float, top: int, text: str, font, fill):
    """Draws text slanted to the right (an italic look that works with any font)."""
    left, t, right, bottom = font.getbbox(text)
    width, height = int(right - left) + 4, int(bottom - t) + 6
    k = 0.21
    pad = int(k * height) + 2
    layer = Image.new("RGBA", (width + pad, height), (0, 0, 0, 0))
    ImageDraw.Draw(layer).text((-left + 2, -t + 2), text, font=font, fill=fill)
    layer = layer.transform(layer.size, Image.AFFINE, (1, k, -k * height, 0, 1, 0), resample=Image.BICUBIC)
    canvas.paste(layer, (int(center_x - layer.width / 2), top), layer)
    return height


# --------------------------------------------------------------------------- #
# Avatar panel
# --------------------------------------------------------------------------- #
def _placeholder_avatar(initial: str) -> Image.Image:
    img = Image.new("RGB", (AVATAR_W, H), (38, 38, 38))
    font = get_font(300)
    draw = ImageDraw.Draw(img)
    letter = (initial or "?")[:1].upper()
    draw.text(((AVATAR_W - font.getlength(letter)) / 2, 110), letter, font=font, fill=(88, 88, 88))
    return img


def _avatar_panel(avatar_bytes, initial: str) -> Image.Image:
    img = None
    if avatar_bytes:
        try:
            img = Image.open(BytesIO(avatar_bytes))
            img.load()
            if img.mode in ("RGBA", "LA", "P"):
                flat = Image.new("RGB", img.size, (0, 0, 0))
                flat.paste(img.convert("RGBA"), mask=img.convert("RGBA").split()[-1])
                img = flat
            img = ImageOps.fit(img.convert("RGB"), (AVATAR_W, H), method=Image.LANCZOS, centering=(0.5, 0.4))
        except Exception:
            img = None
    if img is None:
        img = _placeholder_avatar(initial)
    gray = ImageOps.autocontrast(ImageOps.grayscale(img), cutoff=1)
    return gray.convert("RGB")


def _fade_mask() -> Image.Image:
    """Opaque on the left, fading smoothly to transparent on the right."""
    fade_start = int(AVATAR_W * 0.42)
    row = Image.new("L", (AVATAR_W, 1))
    values = []
    for x in range(AVATAR_W):
        if x <= fade_start:
            values.append(255)
        else:
            t = (x - fade_start) / (AVATAR_W - fade_start)
            values.append(int(255 * (1 - t) ** 1.5))
    row.putdata(values)
    return row.resize((AVATAR_W, H))


# --------------------------------------------------------------------------- #
def render_quote(
    text: str, display_name: str, handle: str = "", avatar_bytes=None, footer: str = "", badge: str = ""
) -> bytes:
    text = clean_text(text) or "\u2026"
    handle = clean_name(handle, fallback="")
    display_name = clean_name(display_name, fallback=handle or "Unknown")
    canvas = Image.new("RGB", (W, H), (0, 0, 0))
    canvas.paste(_avatar_panel(avatar_bytes, display_name), (0, 0), _fade_mask())
    draw = ImageDraw.Draw(canvas)

    quote_font, size, lines, line_h = fit_quote(text)
    name_font = get_font(max(24, min(32, size // 2 + 4)))
    handle_font = get_font(20)

    name_text = _truncate(f"- {display_name}".strip(), name_font, TEXT_W)
    handle_text = _truncate(f"@{handle}", handle_font, TEXT_W) if handle else ""

    name_h = int(name_font.size * 1.3) if hasattr(name_font, "size") else 34
    handle_h = 26 if handle_text else 0
    gap = 26
    block_h = len(lines) * line_h + gap + name_h + (6 + handle_h if handle_text else 0)
    y = max(92 if badge else 36, (H - block_h) // 2)  # leave room for the badge

    for line in lines:
        x = TEXT_CX - quote_font.getlength(line) / 2
        draw.text((x, y), line, font=quote_font, fill=WHITE)
        y += line_h
    y += gap

    _slanted_text(canvas, TEXT_CX, y, name_text, name_font, NAME_COLOR)
    y += name_h + 6
    if handle_text:
        draw.text((TEXT_CX - handle_font.getlength(handle_text) / 2, y), handle_text, font=handle_font, fill=HANDLE_COLOR)

    if footer:
        footer_font = get_font(18)
        footer = _truncate(footer, footer_font, 420)
        draw.text((W - 28 - footer_font.getlength(footer), H - 44), footer, font=footer_font, fill=FOOTER_COLOR)

    if badge:  # a clearly visible label, e.g. FAKE QUOTE, so the image can't pass as the real thing
        badge_font = get_font(30)
        label = badge.upper()
        bw, bh = int(badge_font.getlength(label)) + 36, 52
        x0, y0 = W - 28 - bw, 26
        draw.rounded_rectangle((x0, y0, x0 + bw, y0 + bh), radius=12, fill=(190, 40, 40))
        draw.text((x0 + 18, y0 + 7), label, font=badge_font, fill=WHITE)

    out = BytesIO()
    canvas.save(out, "PNG", optimize=True)
    return out.getvalue()
