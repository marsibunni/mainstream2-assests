"""The gothic leaderboard and level-up images, drawn in the same style as the !level card (level_image.py).
render_leaderboard() and render_levelup() return PNG bytes and have no Discord dependency.
"""
import random
from io import BytesIO

from PIL import Image, ImageDraw, ImageFilter

import level_image as li
from level_image import (CYAN, ICE, MUTED, TEXT, GOLD, INK, GW, G_FRAME, _arch_avatar, _divider, _fit, _glow_text,
                         _gradient_bar, _sparkles, _spaced, _spaced_width, glow_composite, med_font, load_background)
from quote_image import clean_name

# medal tints for the top three, kept inside the cold blue palette
MEDALS = {1: (255, 226, 150), 2: (222, 232, 250), 3: (232, 170, 120)}

ROW_H = 62
HEAD_H = 120
FOOT_H = 52


def _backdrop(width: int, height: int, panel_box) -> Image.Image:
    """The gothic artwork stretched to the card width, cropped to `height`, with a dark panel behind the content."""
    bg = load_background()
    if bg is None:
        img = Image.new("RGBA", (width, height), (4, 8, 24, 255))
        px = ImageDraw.Draw(img)
        for y in range(height):
            t = y / max(1, height - 1)
            px.line((0, y, width, y), fill=(int(4 + 4 * t), int(8 + 14 * t), int(24 + 34 * t), 255))
    else:
        scale = width / bg.width
        scaled = bg.resize((width, int(round(bg.height * scale))), Image.LANCZOS)
        if scaled.height < height:  # very tall boards: stretch the art a little instead of leaving a gap
            scaled = scaled.resize((width, height), Image.LANCZOS)
        img = scaled.crop((0, 0, width, height)).convert("RGBA")
    panel = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(panel).rounded_rectangle(panel_box, radius=18, fill=(3, 7, 22, 205))
    img.alpha_composite(panel.filter(ImageFilter.GaussianBlur(9)))
    vig = Image.new("L", img.size, 0)
    ImageDraw.Draw(vig).ellipse((-220, -160, width + 220, height + 160), fill=255)
    vig = vig.filter(ImageFilter.GaussianBlur(80))
    return Image.composite(img, Image.new("RGBA", img.size, (2, 4, 14, 255)), vig)


def _border(img: Image.Image) -> Image.Image:
    w, h = img.size
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    col = ICE + (230,)
    d.rounded_rectangle((7, 7, w - 8, h - 8), radius=10, outline=col, width=2)
    d.rounded_rectangle((13, 13, w - 14, h - 14), radius=6, outline=ICE + (110,), width=1)
    orn = med_font("orn", 26)
    for (x, y) in ((10, 10), (w - 10, 10), (10, h - 10), (w - 10, h - 10)):
        d.ellipse((x - 11, y - 11, x + 11, y + 11), fill=INK + (255,), outline=col, width=2)
        d.text((x, y), "✠", font=orn, fill=(235, 246, 255, 255), anchor="mm")
    return glow_composite(img, layer, 5, passes=1)


def _diamond(d, cx, cy, s, fill, outline=None):
    d.polygon([(cx, cy - s), (cx + s, cy), (cx, cy + s), (cx - s, cy)], fill=fill, outline=outline)


def _medallion(img: Image.Image, cx: int, cy: int, rank: int) -> Image.Image:
    """A small ornate diamond holding the rank number; the top three are tinted."""
    tint = MEDALS.get(rank)
    ring = tint if tint else ICE
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    _diamond(d, cx, cy, 24, INK + (255,), ring + (255,))
    _diamond(d, cx, cy, 19, None, ring + (120,))
    if tint:
        for dx in (-30, 30):
            _diamond(d, cx + dx, cy, 3, ring + (255,))
    img = glow_composite(img, layer, 5 if tint else 3, passes=2 if tint else 1)
    draw = ImageDraw.Draw(img)
    txt = str(rank)
    f = med_font("demi", 24 if rank < 100 else 17)
    draw.text((cx, cy + 1), txt, font=f, fill=tint or TEXT, anchor="mm")
    return img


def render_leaderboard(rows, page: int, pages: int, title: str = "Leaderboard", seed: int = 0, start_rank: int = 1) -> bytes:
    """rows: list of dicts with keys name, avatar (bytes or None), level, xp (total), into, needed."""
    rng = random.Random(seed or 7)
    n = max(1, len(rows))
    H = HEAD_H + n * ROW_H + FOOT_H
    img = _backdrop(GW, H, (26, 20, GW - 26, H - 20))

    # title
    title = clean_name(title, fallback="Leaderboard")
    shown, tf = _fit(title.upper(), lambda s: med_font("caps", s), 40, GW - 330, min_size=24)
    draw = ImageDraw.Draw(img)
    sp = 6
    tw = _spaced_width(shown, tf, sp)
    tx = (GW - tw) / 2
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    _spaced(ImageDraw.Draw(layer), (tx, 26), shown, tf, TEXT + (255,), sp)
    img = glow_composite(img, layer, 6, passes=1)
    draw = ImageDraw.Draw(img)
    sub = "THE HALL OF FAME"
    sf = med_font("ital", 22)
    sw = sf.getlength(sub)
    draw.text(((GW - sw) / 2, 78), sub, font=sf, fill=MUTED)
    orn = med_font("orn", 26)
    draw.text((tx - 28, 46), "✠", font=orn, fill=GOLD, anchor="mm")
    draw.text((tx + tw + 28, 46), "✠", font=orn, fill=GOLD, anchor="mm")
    img = _divider(img, 70, GW - 70, 108)

    # rows
    L_MED, L_AV, L_NAME = 78, 124, 188
    R = GW - 70
    name_w = 400
    for i, r in enumerate(rows):
        rank = start_rank + i
        y0 = HEAD_H + i * ROW_H
        cy = y0 + ROW_H // 2
        if rank <= 3:  # a faint glow behind the podium rows
            tint = MEDALS[rank]
            hl = Image.new("RGBA", img.size, (0, 0, 0, 0))
            ImageDraw.Draw(hl).rounded_rectangle((52, y0 + 3, GW - 52, y0 + ROW_H - 3), radius=12, fill=tint + (26,), outline=tint + (90,), width=1)
            img = Image.alpha_composite(img, hl)
        img = _medallion(img, L_MED, cy, rank)

        aw, ah = 38, 46
        img.alpha_composite(_arch_avatar(r.get("avatar"), r["name"], aw, ah), (L_AV, cy - ah // 2))
        ring = Image.new("RGBA", img.size, (0, 0, 0, 0))
        ImageDraw.Draw(ring).rounded_rectangle((L_AV - 2, cy - ah // 2 - 2, L_AV + aw + 1, cy + ah // 2 + 1), radius=aw // 2 + 1,
                                               outline=(MEDALS.get(rank) or CYAN) + (200,), width=2)
        img = glow_composite(img, ring, 4, passes=1)

        draw = ImageDraw.Draw(img)
        nm = clean_name(r["name"], fallback="Unknown")
        shown, nf = _fit(nm, lambda s: med_font("demi", s), 28, name_w, min_size=18)
        draw.text((L_NAME, cy - 24), shown, font=nf, fill=TEXT)

        # small progress bar under the name
        bx0, bx1, by = L_NAME, L_NAME + 250, cy + 12
        frac = max(0.0, min(1.0, r["into"] / r["needed"] if r["needed"] else 0))
        draw.rounded_rectangle((bx0, by, bx1, by + 9), radius=4, fill=(8, 16, 46, 255), outline=ICE + (150,), width=1)
        fw = int((bx1 - bx0 - 4) * frac)
        if fw > 6:
            bar = _gradient_bar(fw, 5)
            m = Image.new("L", bar.size, 0)
            ImageDraw.Draw(m).rounded_rectangle((0, 0, bar.width - 1, bar.height - 1), radius=2, fill=255)
            layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
            layer.paste(bar, (bx0 + 2, by + 2), m)
            img = glow_composite(img, layer, 3, passes=1)
        draw = ImageDraw.Draw(img)
        draw.text((bx1 + 12, by - 12), f"{int(frac * 100)}%", font=med_font("ital", 18), fill=MUTED)

        # level (right) and total xp
        lvl = str(r["level"])
        lf = med_font("demi", 36)
        lw = lf.getlength(lvl)
        layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
        ImageDraw.Draw(layer).text((R - lw, cy - 28), lvl, font=lf, fill=(MEDALS.get(rank) or CYAN) + (255,))
        img = glow_composite(img, layer, 5, passes=1)
        draw = ImageDraw.Draw(img)
        cap = med_font("caps", 15)
        _spaced(draw, (R - lw - _spaced_width("LEVEL", cap, 3) - 8, cy - 14), "LEVEL", cap, GOLD, 3)
        xp_txt = f"{r['xp']:,} XP"
        xf = med_font("ital", 22)
        draw.text((R - xf.getlength(xp_txt), cy + 8), xp_txt, font=xf, fill=ICE)

        if i < len(rows) - 1:
            sep = Image.new("RGBA", img.size, (0, 0, 0, 0))
            ImageDraw.Draw(sep).line((70, y0 + ROW_H, GW - 70, y0 + ROW_H), fill=ICE + (45,), width=1)
            img = Image.alpha_composite(img, sep)

    draw = ImageDraw.Draw(img)
    foot = f"Page {page} of {pages}"
    ff = med_font("ital", 22)
    draw.text(((GW - ff.getlength(foot)) / 2, H - FOOT_H + 6), foot, font=ff, fill=MUTED)
    img = _border(img)
    buf = BytesIO()
    img.convert("RGB").save(buf, "PNG", compress_level=4)
    return buf.getvalue()


# --------------------------------------------------------------------------- #
# Level up
# --------------------------------------------------------------------------- #
def _arrow(img: Image.Image, x0: int, x1: int, y: int) -> Image.Image:
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    d.line((x0, y, x1 - 8, y), fill=ICE + (255,), width=3)
    d.polygon([(x1, y), (x1 - 16, y - 11), (x1 - 11, y), (x1 - 16, y + 11)], fill=(235, 248, 255, 255))
    _diamond(d, x0, y, 4, CYAN + (255,))
    return glow_composite(img, layer, 5, passes=2)


def render_levelup(name, avatar_bytes, old_level, new_level, title, old_title=None, needed=0, seed=0) -> bytes:
    """The card posted when someone levels up. `needed` is the XP for the next level (0 hides that line)."""
    rng = random.Random(seed or 3)
    name = clean_name(name, fallback="Unknown")
    bg = load_background()
    if bg is not None:
        img = li._wide_background(bg)
    else:
        img = _backdrop(GW, li.GH, (262, 22, 968, 338))
    H = img.height

    fx0, fy0, fx1, fy1 = G_FRAME
    aw, ah = fx1 - fx0, fy1 - fy0
    halo = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(halo).rounded_rectangle((fx0 - 3, fy0 - 3, fx1 + 3, fy1 + 3), radius=aw // 2, outline=GOLD + (230,), width=3)
    img = glow_composite(img, halo, 10, passes=3)
    img.alpha_composite(_arch_avatar(avatar_bytes, name, aw, ah), (fx0, fy0))
    img = _sparkles(img, rng, 30)

    L, R = 282, 944
    cx = (L + R) // 2

    # LEVEL UP banner
    banner = "LEVEL UP"
    bf = med_font("caps", 40)
    sp = 14
    bw = _spaced_width(banner, bf, sp)
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    _spaced(ImageDraw.Draw(layer), (cx - bw / 2, 24), banner, bf, (235, 246, 255, 255), sp)
    img = glow_composite(img, layer, 9, passes=2)
    draw = ImageDraw.Draw(img)
    orn = med_font("orn", 30)
    for dx in (-(bw / 2 + 30), bw / 2 + 30):
        draw.text((cx + dx, 46), "✠", font=orn, fill=GOLD, anchor="mm")

    # name
    shown, nf = _fit(name, lambda s: med_font("demi", s), 44, R - L - 20, min_size=26)
    nw = nf.getlength(shown)
    img = _glow_text(img, (cx - nw / 2, 84), shown, nf, TEXT, 5, 1)
    img = _divider(img, L, R, 140)

    # old level -> new level
    big = med_font("demi", 100)
    old_s, new_s = str(old_level), str(new_level)
    ow, nw2 = big.getlength(old_s), big.getlength(new_s)
    gap = 120
    total = ow + gap + nw2
    ox = cx - total / 2
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    ImageDraw.Draw(layer).text((ox, 160), old_s, font=big, fill=MUTED + (255,))
    img = Image.alpha_composite(img, layer)
    img = _arrow(img, int(ox + ow + 22), int(ox + ow + gap - 22), 160 + 70)
    img = _glow_text(img, (ox + ow + gap, 160), new_s, big, CYAN, 12, 3)
    draw = ImageDraw.Draw(img)
    lab = med_font("caps", 18)
    _spaced(draw, (ox + ow / 2 - _spaced_width("LEVEL", lab, 4) / 2, 150), "LEVEL", lab, GOLD, 4)
    _spaced(draw, (ox + ow + gap + nw2 / 2 - _spaced_width("LEVEL", lab, 4) / 2, 150), "LEVEL", lab, GOLD, 4)

    # title line
    tf = med_font("caps", 26)
    changed = old_title and old_title != title
    line = f"NEW TITLE   {title}" if changed else title
    lw = _spaced_width(line, tf, 3)
    _spaced(draw, (cx - lw / 2, H - 82), line, tf, ICE, 3)
    if needed:
        nxt = f"{needed:,} XP to level {new_level + 1}"
        xf = med_font("ital", 22)
        draw.text((cx - xf.getlength(nxt) / 2, H - 46), nxt, font=xf, fill=MUTED)

    img = li._ornate_border(img)
    buf = BytesIO()
    img.convert("RGB").save(buf, "PNG", compress_level=4)
    return buf.getvalue()
